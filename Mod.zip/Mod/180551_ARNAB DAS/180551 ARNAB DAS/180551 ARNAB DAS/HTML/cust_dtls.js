function fun1()
{
	alert("Everything is correct");
	windows.open("success.html",_self);
}